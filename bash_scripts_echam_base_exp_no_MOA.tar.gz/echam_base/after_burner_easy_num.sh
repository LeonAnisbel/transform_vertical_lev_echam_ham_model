base_path='/work/bb1005/b381361/my_experiments'
exp="ac3_arctic"
years=('2016' '2017' '2018')

var='NUM'
for yr in "${years[@]}"
do
list=$(ls -d ${base_path}/${exp}/${exp}*$yr*.01_tracer.nc)

for i in $list; do

fnm="${i%_*}"
echo $fnm
fnm1=$(echo ${i} | cut -c1-50 )
fnm1=$(echo ${i} | cut -c1-67 )

fnm2=$(echo ${i} | cut -c31-57 )
plev=$(awk '{print $3","}' pres.txt)
cdo selname,geosp,aps,lsp,gboxarea $i tmp0.nc

cdo setrtoc,-1.e99,0,0 ${i} tmpnonzeros.nc

cdo expr,NUM_ACC=NUM_AS+NUM_AI tmpnonzeros.nc tmpsum_A.nc
cdo expr,NUM_AIT=NUM_KS+NUM_KI tmpnonzeros.nc tmpsum_K.nc
cdo expr,NUM_COA=NUM_CS+NUM_CI tmpnonzeros.nc tmpsum_C.nc
cdo expr,NUM_NUC=NUM_NS tmpnonzeros.nc tmpsum_N.nc

cdo merge tmpsum_A.nc tmpsum_K.nc tmpsum_C.nc tmpsum_N.nc tmpmix.nc

cdo  -mulc,1.2927 -selname,NUM_ACC tmpmix.nc tmpA.nc
cdo setunit,'m-3' -setcode,157 -selname,NUM_ACC tmpA.nc tmpA1.nc
cdo merge tmp0.nc tmpA1.nc tmpA2.nc
# interpolation to pressure levels from file pres.txt
cdo after tmpA2.nc ${fnm}_NUM_ACC_plev.nc << EON
   TYPE=30 CODE=157  LEVEL=${plev}
EON

cdo -mulc,1.2927 -selname,NUM_AIT tmpmix.nc tmpK.nc
cdo setunit,'m-3' -setcode,157 -selname,NUM_AIT tmpK.nc tmpK1.nc
cdo merge tmp0.nc tmpK1.nc tmpK2.nc
# interpolation to pressure levels from file pres.txt
cdo after tmpK2.nc ${fnm}_NUM_AIT_plev.nc << EON
   TYPE=30 CODE=157  LEVEL=${plev}
EON


cdo -mulc,1.2927 -selname,NUM_COA tmpmix.nc tmpC.nc
cdo setunit,'m-3' -setcode,157 -selname,NUM_COA tmpC.nc tmpC1.nc
cdo merge tmp0.nc tmpC1.nc tmpC2.nc
# interpolation to pressure levels from file pres.txt
cdo after tmpC2.nc ${fnm}_NUM_COA_plev.nc << EON
   TYPE=30 CODE=157  LEVEL=${plev}
EON


cdo -mulc,1.2927 -selname,NUM_NUC tmpmix.nc tmpN.nc
cdo setunit,'m-3' -setcode,157 -selname,NUM_NUC tmpN.nc tmpN1.nc
cdo merge tmp0.nc tmpN1.nc tmpN2.nc
# interpolation to pressure levels from file pres.txt
cdo after tmpN2.nc ${fnm}_NUM_NUC_plev.nc << EON
   TYPE=30 CODE=157  LEVEL=${plev}
EON

rm tmp*.nc
done
done
